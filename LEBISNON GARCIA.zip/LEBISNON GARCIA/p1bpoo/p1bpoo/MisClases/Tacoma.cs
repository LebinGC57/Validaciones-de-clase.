﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace p1bpoo.MisClases
{
    internal class Tacoma : Vehiculo
    {
        public Tacoma(int anio, string color, string modelo) : base(anio, color, modelo)
        {
            tiposLicenciaAceptados = new List<string> { "B" };
        }
        public override void Acelerar(int cantidad)
        {
            base.Acelerar(cantidad);
        }
    }
}

