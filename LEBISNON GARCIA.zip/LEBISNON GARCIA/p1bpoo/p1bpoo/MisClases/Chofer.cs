﻿using p1boo.Interfaces;

public class Chofer : Piloto
{
    public string Nombre { get; set; }
    public int Edad { get; set; }
    public string TipoLicencia { get; set; }

    public Chofer(string nombre, int edad, string tipoLicencia)
    {
        Nombre = nombre;
        Edad = edad;
        TipoLicencia = tipoLicencia;
    }
    public void MostrarInformacion()
    {
        Console.WriteLine("Nombre: {0}", this.Nombre);
        Console.WriteLine("Edad: {0}", this.Edad);
        Console.WriteLine("Licencia Tipo: {0}", this.TipoLicencia);
    }
}
