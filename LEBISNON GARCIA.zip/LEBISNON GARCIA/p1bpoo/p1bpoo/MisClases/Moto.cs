﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace p1bpoo.MisClases
{
    internal class Moto : Vehiculo
    {
        public Moto(int anio, string color, string modelo) : base(anio, color, modelo)
        {
            tiposLicenciaAceptados = new List<string> { "M" };
            VelocidadMaxima = 234;
            CapacidadTanque = 15;
            ConsumoCombustible = 0.5;
        }
        public void MostrarInformacionVehiculo()
        {
            base.InformacionVehiculo();
        }

        public void EncenderVehiculo()
        {
            base.Encender();
        }
        public override void Acelerar(int cantidad)
        {
            base.acelerar(cantidad);
        }

        public override void Frenar()
        {
            base.frenar();
        }

        public void AsignarConductor(Chofer conductor)
        {
            base.AsignarPiloto(conductor);
        }

        public void RealizarAcrobacia()
        {
            if (estadoVehiculo == 2)
            {
                Console.WriteLine("Haciendo acrobacias");
            }
            else if (estadoVehiculo == 1)
            {
                Console.WriteLine("No se puede hacer acrobacias si el vehiculo no esta en movimiento");
            }
            else
            {
                Console.WriteLine("No se puede hacer acrobacias si el vehiculo no esta encendido");
            }
        }
    }
}
