﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace p1bpoo.MisClases
{
    public class Vehiculo
    {
        public string Color { get; set; }
        public string Modelo { get; }
        public int Anio { get; }

        protected int velocidad = 0;
        protected int capacidadTanque = 50;
        protected double consumoCombustible = 1;
        protected int velocidadMaxima = 100;

        // tipo de licencia 
        protected List<string> tiposLicenciaAceptados = new List<string> { "A", "B", "C", "M" };
        private Chofer piloto = null;
        protected int estadoVehiculo = 0; // 0=apagado 1=encendido 2=en movimiento

        // agregar el método de asignar piloto
        public string Encender()
        {
            if (piloto == null)
            {
                Console.WriteLine("No puedes encender el vehiculo sin un piloto asignado");
            }
            if (estadoVehiculo == 0)
            {
                estadoVehiculo = 1;
                return "Listo vehiculo arrancado";
            }
            return "El carro ya esta encendido";
        }

        public string AsignarPiloto(Chofer piloto)
        {
            if (piloto == null)
            {
                Console.WriteLine("No se puede asignar un piloto nulo");
            }
            if (!tiposLicenciaAceptados.Contains(piloto.TipoLicencia))
            {
                Console.WriteLine("El piloto no tiene el tipo de licencia adecuado a este carro");
            }
            if (this.piloto != null)
            {
                Console.WriteLine("Este vehiculo ya tiene asignado un piloto");
            }
            this.piloto = piloto;
            return "Piloto asignado con exito";
        }

        public Vehiculo(int anio, string color, string modelo)
        {
            this.Color = color;
            this.Modelo = modelo;
            this.Anio = anio;
        }

        public void MostrarInformacionVehiculo()
        {
            Console.WriteLine("Color: {0}", this.Color);
            Console.WriteLine("Modelo: {0}", this.Modelo);
            Console.WriteLine("Año: {0}", this.Anio);
            Console.WriteLine("La velocidad actual es {0} KMS / Hora", this.velocidad);
            Console.WriteLine("La velocidad maxima del vehiculo es {0} KMS / Hora", this.velocidadMaxima);
            if (estadoVehiculo == 0)
            {
                Console.WriteLine("El vehiculo esta apagado");
            }
            else if (estadoVehiculo == 1)
            {
                Console.WriteLine("El vehiculo esta encendido");
            }
            else
            {
                Console.WriteLine("El vehiculo esta en movimiento");
            }

            if (piloto != null)
            {
                Console.WriteLine("El piloto asignado es {0}", piloto.Nombre);
                Console.WriteLine("El piloto cuenta con la licencia tipo {0}", piloto.TipoLicencia);
            }
            else
            {
                Console.WriteLine("No hay piloto asignado");
            }
        }

        public virtual void Acelerar(int cantidad)
        {
            if (estadoVehiculo == 0)
            {
                Console.WriteLine("No puedes acelerar si el vehiculo esta apagado");
                return;
            }
            velocidad += cantidad;
            if (velocidad > velocidadMaxima)
            {
                velocidad = velocidadMaxima;
                Console.WriteLine("Cuidaaaado, ya no puedes acelerar mas, no puedes superar {0} KMS / Hora", velocidadMaxima);
            }
            Console.WriteLine("Haz acelerado a {0} KMS / Hora", velocidad);
            estadoVehiculo = 2;
        }

        public virtual void Frenar()
        {
            velocidad -= velocidad;
            if (velocidad < 0)
            {
                velocidad = 0;
                estadoVehiculo = 1;
            }
            Console.WriteLine("Vehiculo frenado, vas a {0} KMS / Hora", velocidad);
        }

        public virtual void Apagar()
        {
            if (velocidad >= 1)
            {
                Console.WriteLine("No puedes apagar el vehiculo en movimiento");
            }
            else
            {
                estadoVehiculo = 0;
                Console.WriteLine("Vehiculo apagado");
            }
        }
    }
}
