﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace p1bpoo.MisClases
{
    internal class CarroElectrico : Vehiculo
    {
        private int nivelBateria;
        public CarroElectrico(int anio, string color, string modelo) : base(anio, color, modelo)
        {
            nivelBateria = 50;
        }

        public override void Acelerar(int cantidad)
        {
            base.acelerar(cantidad);
            nivelBateria--;
        }

        public int ObtenerNivelBateria()
        {
            return nivelBateria;
        }

        public void CargarBateria()
        {
            nivelBateria++;
        }
    }
}

