﻿
using System;
using p1boo.Interfaces;
using p1bpoo.MisClases;

namespace p1bpoo
{
    class Program
    {
        static void Main(string[] args)
        {
            Chofer juan = new Chofer("Lebin", 30, "M");
            Chofer jaime = new Chofer("Mario", 25, "M");
            Moto motito = new Moto(2020, "Gris", "Suzuki");

            motito.AsignarPiloto(jaime);
            motito.AsignarPiloto(juan);
            motito.Encender();
            motito.Acelerar(10);
            motito.RealizarAcrobacia();
        }
    }
}


